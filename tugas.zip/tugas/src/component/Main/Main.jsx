import React from 'react';
import Card from '../Card/Card';

const Main = () => {
  return (
    <>
      <Card />
    </>
  );
};

export default Main;
